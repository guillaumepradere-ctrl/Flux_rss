# GitHub Pages RSS

Déposez ce dossier dans un dépôt GitHub puis activez GitHub Pages.
Le fichier sera accessible sous :
https://<username>.github.io/<repo>/rss_test.xml
